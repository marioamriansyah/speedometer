const slider = document.querySelector('.slider');
const valueElem = document.querySelector('#value');

const set = (num) => {
  slider.style.setProperty('--val', num.toString());
  valueElem.textContent = Math.round(num * 100) + '%';
};

let val = 0.10;
set(val);

let oldval;
let startY;
let height;

function slide(ev) {
  ev.preventDefault();
  
  const { clientY } = ev;
  const dy = startY - clientY;
  const dval = dy / height;
  
  val = Math.max(0, Math.min(oldval + dval, 1));
  set(val);
}

slider.addEventListener('pointerdown', (ev) => {
  oldval = val;
  startY = ev.clientY;
  height = slider.clientHeight;
  
  slider.addEventListener('pointermove', slide);
  slider.setPointerCapture(ev.pointerId);
});
slider.addEventListener('pointerup', (ev) => {
  slider.releasePointerCapture(ev.pointerId);
  slider.removeEventListener('pointermove', slide);
});